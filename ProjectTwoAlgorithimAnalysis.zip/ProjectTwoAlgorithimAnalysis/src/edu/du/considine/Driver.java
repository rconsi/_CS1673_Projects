package edu.du.considine;

import java.util.Arrays;
import java.util.Random;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr1 = {-4, 3, 7};
        int[] arr2 = {-15, -7, 3, 6, 7, 9};
        SortSearch sort = new SortSearch();
        System.out.println("Algorithm 1:");
        System.out.println(sort.sequentialSearch(arr1)); // false
        System.out.println(sort.sequentialSearch(arr2)); // true
        
        System.out.println("Algorithm 2:");
        System.out.println(sort.binSearch(arr1)); // false
        System.out.println(sort.binSearch(arr2)); // true
        
        System.out.println("Algorithm 3:");
        System.out.println(sort.algoThree(arr1)); // false
        System.out.println(sort.algoThree(arr2)); // true
        
        // Timing analysis of each algo
        int[] sizes = {50000, 100000, 200000, 400000, 800000};
        for (int size : sizes) {
        	int[] arr = new int[size];
        	Random rand = new Random();
			for (int i = 0; i < size; i++) {
				arr[i] = rand.nextInt(size);
			}
            
            long start1 = System.nanoTime();
            sort.sequentialSearch(arr);
            long end1 = System.nanoTime();
            double time1 = (end1 - start1) / 1e9;
            
            long start2 = System.nanoTime();
            sort.binSearch(arr);
            long end2 = System.nanoTime();
            double time2 = (end2 - start2) / 1e9;
            
            long start3 = System.nanoTime();
            sort.algoThree(arr);
            long end3 = System.nanoTime();
            double time3 = (end3 - start3) / 1e9;
            
            System.out.printf("Array size: %d, Algorithm 1 time: %.6f s, Algorithm 2 time: %.6f s, Algorithm 3 time: %.6f s\n", size, time1, time2, time3);
        }
	}
}



