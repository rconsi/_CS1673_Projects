package edu.du.considine;

import java.util.Arrays;

public class SortSearch {

	//ALGORITHIM HAS BIG O NOTATION OF O(n)
			public boolean sequentialSearch(int[] arr) {
				int size = arr.length;
				for (int i = 0; i < size; i++) {
					int neg = -arr[i];
					for( int j = 0; j < size; j++) {
						if(arr[j] == neg) {
							return true;
						}
					}
				}
				return false;
			}
			
			/***
			 * input:  x (value we are searching for)
		      first  =  0
		      last = arraySize-1
		      while first <= last do
		           middle = (first+last)/2
		           if  array[middle] == x
		               return true
		           else if x < array[middle]
		                last = middle - 1
		           else
		                 first = middle + 1
		      end
		       return false;
			 * @param arr
			 * @return
			 */
			
			//ALGORITHIM HAS BIG O NOTATION OF O(log(n))
			public boolean binSearch(int[] arr) {
				int size = arr.length;
				Arrays.sort(arr);
				//sort through array using the binary serch method
				//if neg is found, return true
				for(int i = 0; i < size; i++) {
					int neg = -arr[i];
					boolean numFound = binarySearch(arr,neg);
					if (numFound) {
						return true;
					}
				}
				return false;
			}
			
			
			//PERFORMS THE ACTUAL BINARY SEARCH METHOD TO BE INVOKED IN BINSEARCH()
			public boolean binarySearch(int arr[], int key) {
				int first = 0;
				int last = arr.length - 1;
				//PERFORM THE SORT WHILE FIRST IS LESS THAN OR EQUAL TO LAST
				//SET THE MID POINT
				while (first <= last) {
					int mid = (first + last) / 2;
					//IF MID IS THE KEY, RETURN TRUE, VALUE HAS BEEN FOUND
					if (arr[ mid ] == key) {
						return true;
					} else if (key < arr[ mid ]) {
						//IF KEY IS LESS THAN MID, SET LAST TO ONE LESS THAN MID
						last = mid - 1;
					} else {
						//ELSE, SET FIRST = TO 1 MORE THAN MID
						first = mid + 1;
					}
				}
				return false;
			}
			//ALGORITHIM HAS BIG O NOTATION OF O(n)
			public boolean algoThree(int[] arr) {
				int i = arr[0];
				int j = arr[arr.length - 1];
				while(i < j) {
					//WHILE I IS LESS THA J, CHECK IF I + J = 0, 
					//IF IT IS 0, THEN IT IS FOUND, RETURN TRUE
					//IF ITS LESS, INCRMEMENT I
					//IF ITS MORE, DECREMENT J
					if (i + j == 0) {
						return true;
					} else if( i + j < 0){
						i++;
					}	
					else {
						j--;
					}
					
				}
				return false;
			}
}
