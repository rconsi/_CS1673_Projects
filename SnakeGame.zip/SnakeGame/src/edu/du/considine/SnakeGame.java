package edu.du.considine;
import edu.du.dudraw.DrawListener;
import java.util.LinkedList;
import javax.swing.text.Segment;
import java.util.Random;
import edu.du.dudraw.DUDraw;
import edu.du.dudraw.Draw;

public class SnakeGame implements DrawListener {
	private Draw draw;
	//linked list for the snake segments
	private LinkedList<Segment> snake;
	//global variables for x and y values
	private static int gxValue;
	private static int gyValue;
	//global direction variable to keep track of the direction of the snake
	private Direction checkDirection;
	//create the enum for direction to check the directions and keep track
	enum Direction {N, S, E, W;}
	public SnakeGame() {
		//start the game with 3 snake segments initially 
		//create a linked list 
		snake = new LinkedList<Segment>();
		Segment sOne = new Segment(10,8);
		Segment sTwo = new Segment(10,7);
		Segment sThree = new Segment(10,6);
		//Setup the food on the game board
		SnakeGame.setFood();
		draw = new Draw();
		//Set canvas size for the game board
		DUDraw.setCanvasSize(350,350);
		draw.setXscale(-0.5,14.5);
		draw.setYscale(-0.5,14.5);
		draw.addListener(this);
		draw.startUpdate();
		draw.setFrameTime(80);
		draw.enableDoubleBuffering();
		snake.addFirst(sOne);
		snake.addFirst(sTwo);
		snake.addFirst(sThree);
	}
	//method to create random food points throughout the game map
	public static void setFood(){
		Random rnd = new Random();
		gxValue = rnd.nextInt(15);
		gyValue = rnd.nextInt(15);
	}
	//method to create each segment, the next segment will be assigned an x and y value
	public class Segment{
		private int myX;
		private int myY;
		public Segment(int x, int y) {
			this.myX = x;
			this.myY = y;
		}
	}
	//method to check which key is pressed, and updates the direction checker
	public void keyPressed(int key) {
		//If W key is pressed, check if the snake is moving in the right direction,
		//if its moving down do nothing, if moving east or west, set movement to up
		if (key == 87 || key == 224) {
			if (checkDirection == Direction.S) {
				return;
			} else {
				checkDirection = Direction.N;
			}
		}
		//If S key is pressed, check if the snake is moving in the right direction,
		//if its moving up do nothing, if moving east or west, set movement to down
		if (key == 83 || key == 225) {
			if (checkDirection == Direction.N) {
				return;
			} else {
				checkDirection = Direction.S;
			}
		}
		//If A key is pressed, check if the snake is moving in the right direction,
		//if its moving East do nothing, if moving North or South, set movement to West
		if (key == 65 || key == 226) {
			if(checkDirection == Direction.E) {
				return;
			} else {
				checkDirection = Direction.W;
			}
		}
		//If D key is pressed, check if the snake is moving in the right direction,
		//if its moving West do nothing, if moving North or South, set movement to East
		if (key == 68 || key == 227) {
			if(checkDirection == Direction.W) {
				return;
			} else {
				checkDirection = Direction.E;
			}
		}
	}
	//key checker logic
	@Override
	public void keyReleased(int key0) {
	}
	@Override
	public void keyTyped(char key0) {
	}
	@Override
	public void mouseClicked(double arg0, double arg1) {
	}
	@Override
	public void mouseDragged(double arg0, double arg1) {
	}
	@Override
	public void mouseReleased(double arg0, double arg1) {
	}
	@Override
	public void mousePressed(double arg0, double arg1) {
	}
	public void update() {
		draw.clear();
		//remove the last, add a new first element to the snake
		//If the snake is moving north, add the new segment in the proper position
		if (checkDirection == Direction.N) {
			Segment t = new Segment(snake.get(0).myX, snake.get(0).myY + 1);
			snake.add(0,t);
		} //If the snake is moving south, add the new segment in the proper position
		else if(checkDirection == Direction.S) {
			Segment t = new Segment(snake.get(0).myX, snake.get(0).myY - 1);
			snake.add(0,t);
		}//If the snake is moving east, add the new segment in the proper position
		else if(checkDirection == Direction.E) {
			Segment t = new Segment(snake.get(0).myX + 1, snake.get(0).myY);
			snake.add(0,t);
		}//If the snake is moving west, add the new segment in the proper position
		else{
			Segment t = new Segment(snake.get(0).myX - 1, snake.get(0).myY);
			snake.add(0,t);
		}
		if (snake.get(0).myX == gxValue && snake.get(0).myY == gyValue) {
			updateFood();
		} else {
			snake.removeLast();
		}
		for (int i = 0; i < snake.size(); i++) {
			//this loop draws the snake
			draw.setPenColor(Draw.BLACK);
			draw.square(snake.get(i).myX, snake.get(i).myY, 0.5);
			draw.setPenColor(Draw.GREEN);
			draw.filledSquare(snake.get(i).myX, snake.get(i).myY, 0.5);
			draw.setPenColor(Draw.BLACK);
			draw.filledCircle(gxValue, gyValue, 0.6);
			draw.setPenColor(Draw.RED);
			draw.filledCircle(gxValue, gyValue, 0.5);
			draw.setPenColor(Draw.GREEN);
			checkEndGame(i);
		}
		draw.show();
	}
	//function which is called when the snake goes out of bounds or runs into itself
	//I believe I need to use the stopUpdate() function from Draw class 
	//however it doesn't exist in the library even though it should
	public void endGame() {
		//draw.clear();
		draw.stopUpdate();
		draw.setPenColor(Draw.BLACK);
		draw.rectangle(7.25, 7.25, 2, 1);
		draw.setPenColor(Draw.BOOK_LIGHT_BLUE);
		draw.filledRectangle(7.25, 7.25, 2, 1);
		draw.setPenColor(Draw.WHITE);
		draw.text(7.25, 7.25, " Game Over! ");
		
	}
	//checks each action which would result in the game ending, if they occur, run the endGame method to end the game for the user
	public void checkEndGame(int temp) {
		//if the snake exits the bounds of the game board, end the game
		if (snake.get(0).myX > 14.5 || snake.get(0).myX < 0 || snake.get(0).myY > 14.5 || snake.get(0).myY < 0) {
			endGame();
		}
		//if the snake runs into any part of itself, end the game
		if (temp > 0) {
			if (snake.get(0).myX == snake.get(temp).myX && snake.get(0).myY == snake.get(temp).myY && temp > 0) {
				endGame();
			}
		}
	}
	//checks when the snake eats, if the snake reaches the food update the food with a new location
	public void updateFood() {
		SnakeGame.setFood();
		if (checkDirection == Direction.N) {
			Segment t = new Segment(snake.get(0).myX,snake.get(0).myY + 1);
			snake.add(0,t);
		}
		else if(checkDirection == Direction.S) {
			Segment t = new Segment(snake.get(0).myX, snake.get(0).myY - 1);
			snake.add(0,t);
		}
		else if(checkDirection == Direction.E) {
			Segment t = new Segment(snake.get(0).myX + 1, snake.get(0).myY);
			snake.add(0,t);
		}
		else {
			Segment t = new Segment(snake.get(0).myX - 1, snake.get(0).myY);
			snake.add(0,t);
		}
	}
	
	
}
