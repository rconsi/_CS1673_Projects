package edu.du.considine;

public class TestDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SnakeGame FirstGame = new SnakeGame();
		FirstGame.update();
		
	}

}
