package edu.du.considine;
import java.awt.Color;
import java.awt.Font;

import edu.du.dudraw.DUDraw;
enum PixelType {EMPTY, SAND, WATER, FLOOR, WATERFALL};

public class SandWorld {
	int toolClear = 0;
	PixelType [][] worldPxls;
	int size;
	public PixelType currentTool;
	Color SAND = new Color( 176, 141, 91 );
	
	public SandWorld(int size, PixelType type) {
		//Set up type, set to empty initially, create a 2-D array to store all the pixels in called worldPxls
		this.size = size;
		worldPxls = new PixelType[size][size];
		DUDraw.setCanvasSize(size,size);
		DUDraw.setScale(0,size);
		DUDraw.setPenColor(DUDraw.LIGHT_GRAY);
		DUDraw.filledRectangle(300,300,400,400);
		DUDraw.setPenColor(DUDraw.YELLOW);
		DUDraw.filledCircle(100, 500, 50);
		DUDraw.setPenColor(DUDraw.ORANGE);
		DUDraw.filledCircle(100, 500, 30);
			DUDraw.setPenColor(DUDraw.WHITE);
			DUDraw.filledCircle(530, 520, 20);
			DUDraw.filledCircle(515, 505, 30);
			DUDraw.filledCircle(480, 510, 20);
			DUDraw.filledCircle(490, 530, 20);
			DUDraw.filledCircle(500, 540, 20);

		//Determines the current tool being used and sets the pixels based on the tool type
		if(type != PixelType.EMPTY) {
			currentTool = PixelType.EMPTY;
		} 
		currentTool = type;
		for(double r = 0.0; r < worldPxls.length; r++) {
			for (double c = 0.0; c < worldPxls[0].length; c++) {
				worldPxls[(int) r][(int) c] = currentTool;
			}
		}
		for(int row = 0; row < worldPxls.length; row++) {
			worldPxls [row][0] = PixelType.FLOOR;
		}
	}
	//Create the place particle class, which will determine which type of tool is being used
	public boolean placeParticle(double row, double col) {
		double sprinkRow = (int) (Math.random() * 20 - 10);
		double sprinkCol = (int) (Math.random() * 10);
			if (worldPxls[ ( int ) row ] [ (int) col ] != PixelType.EMPTY) {
				return false;
			} 
			else {
				//If sand is selected, place the points with a SAND color
				if(currentTool == PixelType.SAND) {
					worldPxls[(int) ( row + sprinkRow )][ (int) (col + sprinkCol)] = PixelType.SAND;
					DUDraw.setPenColor(SAND);
					DUDraw.point( sprinkRow + row , col - sprinkCol);
				}
				if(currentTool == PixelType.FLOOR) {
					worldPxls[ (int) row][ (int) col] = PixelType.FLOOR;
					DUDraw.setPenColor(DUDraw.BLACK);
					DUDraw.filledCircle(row, col, 10);
					DUDraw.filledCircle(row + 1, col, 10);
					DUDraw.filledCircle(row - 1, col, 10);
				}
				//If water is selected, place the points with a blue color with similar properties to the sand tool
				if(currentTool == PixelType.WATER) {
					worldPxls[(int) ( row + sprinkRow)][ (int) (col + sprinkCol)] = PixelType.WATER;
					DUDraw.setPenColor(DUDraw.BOOK_LIGHT_BLUE);
					DUDraw.point( sprinkRow + row , col );
					}
				if (currentTool == PixelType.WATERFALL) {
					worldPxls[(int) ( row + sprinkRow)][ (int) (col + sprinkCol)] = PixelType.WATERFALL;
					DUDraw.setPenColor(DUDraw.BOOK_LIGHT_BLUE);
					DUDraw.point( sprinkRow + row , col  );
				}
			}
			return true;
	}
	//Changes the state of pixels in the world based on the pixels around it
	public void step() {
		for (double row = 0.0; row < worldPxls.length; row++) {
			for (double col = 0.0; col < worldPxls[0].length; col++) {
				if (worldPxls [(int) row][(int) col] == PixelType.SAND) {
					stepSand( row, col);
				}
				if (worldPxls [(int) row] [(int) col] == PixelType.WATER) {
					stepWater( row, col);
				}
				if (worldPxls [(int) row] [(int) col] == PixelType.WATERFALL) {
					stepWaterFall( row, col);
				}
			} 
		}
	}
	//changes the sand pixels in the world based on the pixels around it
	public void stepSand(double row , double col) {
		double sDown = col - 1;
		if (worldPxls [(int) row] [(int) sDown] == PixelType.EMPTY) {
			sandDown ( row, col, sDown);
		} else {
			sandSlide( row , col , sDown);
		}
	}
	//sandDown is called when the pixel can fall down, and it updates the world by 
	//moving the sand pixel down one row and erasing the previous position.
	public void sandDown(double row , double col, double sDown) {
		if ( col > 0 ) {
			worldPxls [(int) row] [ (int) col] = PixelType.EMPTY;
			worldPxls [(int) row] [ (int) sDown ] = PixelType.SAND;
			DUDraw.setPenColor(DUDraw.LIGHT_GRAY);
			DUDraw.point( row - 1 , col );
			DUDraw.point(row + 1, col);
			DUDraw.point(row, col);
			DUDraw.setPenColor(SAND);
			DUDraw.point( row , sDown );
		}
	}
	//Create the method which allows the sand to slide correctly when placed
	public void sandSlide(double row, double col, double sDown) {
		double left = row - 1;
		double right = row + 1;
		if (row < size - 1) {
			if(right <= size) {
				if(worldPxls [(int) right][(int) sDown] == PixelType.EMPTY && worldPxls[(int) row][(int) sDown] == PixelType.SAND){
					worldPxls[(int) right][(int) sDown] = PixelType.SAND;
					worldPxls[(int) row][(int) sDown] = PixelType.EMPTY;
					DUDraw.setPenColor(DUDraw.LIGHT_GRAY);
					DUDraw.point(row, col);
					DUDraw.setPenColor(SAND);
					DUDraw.point(right, sDown);
				}
		}
		
}
	
				if (col > 0) {
					if(left >=  0) {
						if(worldPxls [(int) left] [(int) sDown] == PixelType.EMPTY && worldPxls [(int) row] [(int) sDown] == PixelType.SAND) {
							worldPxls [(int) left] [(int) sDown] = PixelType.SAND;
							worldPxls [(int) row] [(int) sDown] = PixelType.EMPTY;
							DUDraw.setPenColor(DUDraw.LIGHT_GRAY);
							DUDraw.point(row, col);
							DUDraw.setPenColor(SAND);
							DUDraw.point(left, sDown);
				}
			}
		}
	}
	//Create the stepWater function for the water tool
	
	public void stepWater(double row , double col) {
		double wDown = col - 1;
		if (worldPxls [(int) row] [(int) wDown] == PixelType.EMPTY) {
			waterDown ( row, col, wDown);
		} else {
			waterSlide( row , col, wDown);
		}
	}
	//waterDown is called when the pixel can fall down, and it updates the world by 
	//moving the water pixel down one row and erasing the previous position.
	public void waterDown(double row , double col, double wDown) {
		if ( col > 0 ) {
			worldPxls [(int) row] [ (int) col] = PixelType.EMPTY;
			worldPxls [(int) row] [ (int) wDown ] = PixelType.WATER;
			DUDraw.setPenColor(DUDraw.LIGHT_GRAY);
			DUDraw.point( row - 1 , col );
			DUDraw.point(row + 1, col);
			DUDraw.point(row, col);
			DUDraw.setPenColor(DUDraw.BOOK_LIGHT_BLUE);
			DUDraw.point( row , wDown );
		}
	}
	//create the actual waterSlide method which will replace the pixels in the world with moving water particles if the pixels are EMPTY
	public void waterSlide(double row, double col, double wDown) {
		double left = row - 1;
		double right = row + 1;
		//if the water hits the ground
		if (row < size - 1) {
			if(right <= size) {
				if(worldPxls [(int) right][(int) wDown] == PixelType.EMPTY && worldPxls[(int) row][(int) wDown] == PixelType.WATER){
					worldPxls[(int) right][(int) wDown] = PixelType.WATER;
					worldPxls[(int) row][(int) wDown] = PixelType.EMPTY;
					DUDraw.setPenColor(DUDraw.LIGHT_GRAY);
					DUDraw.point(row , col);
					DUDraw.setPenColor(DUDraw.BOOK_LIGHT_BLUE);
					DUDraw.point(right, wDown);
					//DUDraw.clear();
					
				}
		}
		
}
	
				if (col > 0) {
					if(left >=  0) {
						if(worldPxls [(int) left] [(int) wDown] == PixelType.EMPTY && worldPxls [(int) row] [(int) wDown] == PixelType.WATER) {
							worldPxls [(int) left] [(int) wDown] = PixelType.WATER;
							worldPxls [(int) row] [(int) wDown] = PixelType.EMPTY;
							DUDraw.setPenColor(DUDraw.BOOK_LIGHT_BLUE);
							DUDraw.point(row, col);
							DUDraw.setPenColor(DUDraw.BOOK_LIGHT_BLUE);
							DUDraw.point(left, wDown);
				}
			}
		}
	}	
	/*
	 * waterfall step function, decides whether to invoke the slide method or the fall down method 
	 * depending if it detects pixels below it or not 
	*/
	public void stepWaterFall(double row , double col) {
		double wfDown = col - 1;
		if (worldPxls [(int) row] [(int) wfDown] == PixelType.EMPTY) {
			waterFallDown ( row , col , wfDown);
		} else {
			waterFallSlide( row , col, wfDown);
		}
	}
	//waterFallDown is called when the pixel can fall down, and it updates the world by 
	//moving the water pixel down one row but rather than replacing the previous with an empty space
	//it will create a waterfall effect
	public void waterFallDown(double row , double col, double wfDown) {
		if ( col > 0 ) {
			worldPxls [(int) row] [ (int) col] = PixelType.EMPTY;
			worldPxls [(int) row] [ (int) wfDown  ] = PixelType.WATERFALL;
			DUDraw.setPenColor(DUDraw.LIGHT_GRAY);
			DUDraw.point(row , wfDown);
			DUDraw.setPenColor(DUDraw.BOOK_LIGHT_BLUE);
			DUDraw.point( row , wfDown );
		}
	}
	//create the actual waterFallSlide method which will replace the pixels in the world with 
	//moving water particles if the pixels are EMPTY
	
	public void waterFallSlide(double row, double col, double wfDown) {
		double left = row - 1;
		double right = row + 1;
		//if the water hits the ground
		if (row < size - 1) {
			if(right <= size) {
				if(worldPxls [(int) right][(int) wfDown] == PixelType.EMPTY && worldPxls[(int) row][(int) wfDown] == PixelType.WATERFALL){
					worldPxls[(int) right][(int) wfDown] = PixelType.WATERFALL;
					worldPxls[(int) row][(int) wfDown] = PixelType.EMPTY;
					DUDraw.setPenColor(DUDraw.LIGHT_GRAY);
					DUDraw.point(row , col);
					DUDraw.setPenColor(DUDraw.BOOK_LIGHT_BLUE);
					DUDraw.point(row , col );
					DUDraw.point(right, wfDown);
					
					
				}
		}
		
}
	
				if (col > 0) {
					if(left >=  0) {
						if(worldPxls [(int) left] [(int) wfDown] == PixelType.EMPTY && worldPxls [(int) row] [(int) wfDown] == PixelType.WATERFALL) {
							worldPxls [(int) left] [(int) wfDown] = PixelType.WATERFALL;
							worldPxls [(int) row] [(int) wfDown] = PixelType.EMPTY;
							DUDraw.setPenColor(DUDraw.LIGHT_GRAY);
							DUDraw.point(row, col);
							DUDraw.setPenColor(DUDraw.BOOK_LIGHT_BLUE);
							DUDraw.point(left, wfDown);
				}
			}
		}
	}
	//Displays the type of tool being using
	public void displayToolName(PixelType type) {
		DUDraw.setPenColor(DUDraw.BOOK_LIGHT_BLUE);
		DUDraw.filledRectangle(size / 2, size - 20, size / 4, 15);
		DUDraw.setPenColor(DUDraw.BLACK);
		 Font font = new Font("Arial", Font.BOLD, 25);
		 DUDraw.setFont(font);
		DUDraw.setPenRadius(5);
		if (type == PixelType.EMPTY) {
			DUDraw.text(size / 2, size - 20, "Empty");
		}
		if (type == PixelType.SAND) {
			DUDraw.text(size / 2, size - 20, "Sand");
		}
		if (type == PixelType.FLOOR) {
			DUDraw.text(size / 2, size - 20, "Floor");
		}
		if (type == PixelType.WATER) {
			DUDraw.text(size / 2, size - 20, "Water");
		}
		if (type == PixelType.WATERFALL) {
			DUDraw.text(size / 2, size - 20, "WaterFall");
		}
		setType(type);
	}
	//Sets the type depending on the selected tool type
	public void setType (PixelType type) {
		currentTool = type;
	}
	//Getter method for type of tool
	public PixelType getType() {
		return currentTool;
	}
}