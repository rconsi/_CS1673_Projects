package edu.du.considine;

import edu.du.dudraw.DUDraw;

public class SandGame {

	public static void main(String[] args) {
		/* UN-NECESSARY
		DUDraw.setCanvasSize( 600,600 );
		DUDraw.setScale( 0, 600 );
		DUDraw.setPenColor(DUDraw.BOOK_LIGHT_BLUE);
		DUDraw.filledRectangle(5, 5, 600, 600);
		DUDraw.setPenColor(DUDraw.PRINCETON_ORANGE);
		DUDraw.filledRectangle(2, 2, 600, 100);
		*/
		SandWorld NewWorld = new SandWorld(600, PixelType.EMPTY);

		boolean loop = true;
		DUDraw.enableDoubleBuffering();
		//creates an infinite loop which checks whether a key is pressed and where the mouse is clicked
		while(loop) {
			//checks for the 'S' key being pressed, if it is the tool type is switched and displayed at the top
			if (DUDraw.isKeyPressed(83)) {
				NewWorld.displayToolName(PixelType.SAND);
				
			}
			//checks for the 'F' key being pressed, if it is the tool type is switched and displayed at the top
			if (DUDraw.isKeyPressed(70)) {
				NewWorld.displayToolName(PixelType.FLOOR);
			}
			//checks for the 'W' key being pressed, if it is the tool type is switched and displayed at the top
			if ( DUDraw.isKeyPressed(87)) {
				NewWorld.displayToolName(PixelType.WATER);
			}
			//checks for the 'L' key being pressed, if it is the tool type is switched and displayed at the top
			if (DUDraw.isKeyPressed(76)) {
				NewWorld.displayToolName(PixelType.WATERFALL);
			}
			//checks for where the mouse is being pressed, if it is pressed then a particle is placed depending on the tool type
			if (DUDraw.isMousePressed()) {
				NewWorld.placeParticle(DUDraw.mouseX(),DUDraw.mouseY());
			}
			NewWorld.step();
			DUDraw.pause(5);
			DUDraw.show();
			//quit function if the 'Q' key is pressed
			if (DUDraw.isKeyPressed(81)) {
				loop = false;
			}
		}
	}
}
